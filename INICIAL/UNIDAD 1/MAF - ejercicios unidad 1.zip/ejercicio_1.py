# Cree un programa que tome tres valores por consola multiplique 
# primero por el segundo y le sume el tercero

# Solicito los valores al usuario / a

valor_1 = int(input("Por favor ingresá un número entero: "))
valor_2 = int(input("Por favor ingresá un número entero: "))
valor_3 = int(input("Por favor ingresá un número entero: "))

# Realizo las operaciones

resultado_final = (valor_1 * valor_2) + valor_3

# Muestro el resultado final

print ("El resultado final es:", resultado_final)