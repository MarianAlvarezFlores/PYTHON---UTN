# Pi

PI = 3.1416

# Le pedimos al usuario que ingrese el radio

radio = float(input("Ingresá el radio: "))

# Calculamos el área usando la fórmula A = pi * r^2

area = PI * (radio ** 2)

# Presentamos el resultado en la terminal

print ("El área es:", area)