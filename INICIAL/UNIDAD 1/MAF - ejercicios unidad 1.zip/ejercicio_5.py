# Le pedimos al usuario/a que ingrese un valor entero

valor = int(input("Ingrese un valor entero: "))

# Incremento del 10%

incremento = valor * 0.10

valor_incrementado = valor + incremento

# Resultado

print("El valor incrementado en un 10% es:", valor_incrementado)