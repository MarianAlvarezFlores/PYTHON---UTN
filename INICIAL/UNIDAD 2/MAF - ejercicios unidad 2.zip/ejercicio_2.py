# Cree una lista de frutas de 2 elementos, y realice un programa que muestre una oración
# conteniendo los dos elementos de la lista concatenándolos con texto para formar una
# oración con sentido. Presente el resultado en la terminal del editor

# Creo una lista con 2 elementos que deben ser frutas

frutas = ["manzana", "naranja"]

# Concateno los elementos de la lista en una oración

oracion_1 = "Hoy compré una " + frutas[0] + " y una " + frutas[1] + " en la verdulería"

# Muestro el resultado en la terminal

print(oracion_1)