# Tome dos valores por consola, y guarde en una lista:
# [primer_valor, segundo_valor, la_suma_de_los_valores]

# Pido dos valores al usuario/a

primer_valor = int(input("Ingresá el primer valor: "))
segundo_valor = int(input("Ingresá el segundo valor: "))

# Calculo la suma de los dos valores

suma = primer_valor + segundo_valor

# Guardo los valores en una lista

valores = [primer_valor, segundo_valor, suma]

# Mostrar la lista en la terminal
print("La lista es:", valores)