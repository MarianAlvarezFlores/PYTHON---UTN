# Crear una función lambda que sea equivalente a la siguiente función:

#def multiplicar_por_tres(valor):
# res = 3 * valor
# return res 

multiplicar_por_3 = lambda valor: 3 * valor
print (multiplicar_por_3 (3))
