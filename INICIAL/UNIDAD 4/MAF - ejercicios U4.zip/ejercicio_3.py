# Crear una función lambda que sea equivalente a la
#def sumar(valor1, valor2):
# res = valor1 + valor2
# return res

sumar = lambda  valor_1, valor_2 : valor_1 + valor_2

print (sumar (2, 3))