# Cree una función que tome la siguiente lista y reordene de menor a mayor sus componentes:
lista = [3, 44, 21, 78, 5, 56, 9]

def ordenar_lista (lista):
    nueva_lista_ordenada = sorted (lista)
    print (nueva_lista_ordenada)

print (lista)
ordenar_lista (lista)